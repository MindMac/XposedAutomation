package de.robv.android.xposed.installer;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.List;

import de.robv.android.xposed.installer.util.AssetUtil;
import de.robv.android.xposed.installer.util.ModuleUtil;
import de.robv.android.xposed.installer.util.RootUtil;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import android.widget.TextView;

public class InstallService extends Service{
	private Context mContext = null;
	private RootUtil mRootUtil = new RootUtil();
	private ModuleUtil mModuleUtil = ModuleUtil.getInstance();
	
	private static final String XPOSED_MODULE = "xposed_module";
	private String APP_PROCESS_NAME = null;
	private final String BINARIES_FOLDER = AssetUtil.getBinariesFolder();
	private static final String JAR_PATH = XposedApp.BASE_DIR + "bin/XposedBridge.jar";
	private static final String JAR_PATH_NEWVERSION = JAR_PATH + ".newversion";
	
	private final LinkedList<String> mCompatibilityErrors = new LinkedList<String>();
	
	
	@Override  
    public void onCreate() {  
        super.onCreate();  
        
    }  
  
    @Override  
    public int onStartCommand(Intent intent, int flags, int startId) {  
        mContext = InstallService.this;
	
    	boolean isCompatible = false;
    	
		Bundle extras = intent.getExtras();
		if (extras != null) {
			String packageName = (extras.containsKey(XPOSED_MODULE) ? extras.getString(XPOSED_MODULE) : null);
			if(packageName != null){
				if (BINARIES_FOLDER == null) {
					// incompatible processor architecture
				} else if (Build.VERSION.SDK_INT == 15) {
					APP_PROCESS_NAME = BINARIES_FOLDER + "app_process_xposed_sdk15";
					isCompatible = checkCompatibility();
		
				} else if (Build.VERSION.SDK_INT >= 16 && Build.VERSION.SDK_INT <= 19) {
					APP_PROCESS_NAME = BINARIES_FOLDER + "app_process_xposed_sdk16";
					isCompatible = checkCompatibility();
		
				} else if (Build.VERSION.SDK_INT > 19) {
					APP_PROCESS_NAME = BINARIES_FOLDER + "app_process_xposed_sdk16";
					isCompatible = checkCompatibility();
				}
				
				if(isCompatible){
					boolean success = install();
					if(success){
						enableModule(packageName);
						reboot(null);
					}
				}
			}
		}

	    return super.onStartCommand(intent, flags, startId);
    }  
      
    @Override  
    public void onDestroy() {  
        super.onDestroy();  
        mRootUtil.dispose();
    }  
	
	private boolean checkCompatibility() {
		mCompatibilityErrors.clear();
		return checkAppProcessCompatibility();
	}
	
	private boolean checkAppProcessCompatibility() {
		try {
			if (APP_PROCESS_NAME == null)
				return false;

			File testFile = AssetUtil.writeAssetToCacheFile(APP_PROCESS_NAME, "app_process", 00700);
			if (testFile == null) {
				mCompatibilityErrors.add("could not write app_process to cache");
				return false;
			}

			Process p = Runtime.getRuntime().exec(new String[] { testFile.getAbsolutePath(), "--xposedversion" });

			BufferedReader stdout = new BufferedReader(new InputStreamReader(p.getInputStream()));
			String result = stdout.readLine();
			stdout.close();

			BufferedReader stderr = new BufferedReader(new InputStreamReader(p.getErrorStream()));
			String errorLine;
			while ((errorLine = stderr.readLine()) != null) {
				mCompatibilityErrors.add(errorLine);
			}
			stderr.close();

			p.destroy();

			testFile.delete();
			return result != null && result.startsWith("Xposed version: ");
		} catch (IOException e) {
			mCompatibilityErrors.add(e.getMessage());
			return false;
		}
	}
	
	private boolean startShell() {
		if (mRootUtil.startShell())
			return true;

		showAlert(mContext.getString(R.string.root_failed));
		return false;
	}
	
	private void showAlert(String result){
		AlertDialog dialog = new AlertDialog.Builder(mContext)
		.setMessage(result)
		.setPositiveButton(android.R.string.ok, null)
		.create();
		dialog.show();
		TextView txtMessage = (TextView) dialog.findViewById(android.R.id.message);
		txtMessage.setTextSize(14);
	}
	
	private boolean install() {

		if (!startShell())
			return false;

		List<String> messages = new LinkedList<String>();
		try {
			messages.add(mContext.getString(R.string.sdcard_location, XposedApp.getInstance().getExternalFilesDir(null)));
			messages.add("");

			messages.add(mContext.getString(R.string.file_copying, "Xposed-Disabler-Recovery.zip"));
			if (AssetUtil.writeAssetToSdcardFile("Xposed-Disabler-Recovery.zip", 00644) == null) {
				messages.add("");
				messages.add(mContext.getString(R.string.file_extract_failed, "Xposed-Disabler-Recovery.zip"));
				return false;
			}

			File appProcessFile = AssetUtil.writeAssetToFile(APP_PROCESS_NAME, new File(XposedApp.BASE_DIR + "bin/app_process"), 00700);
			if (appProcessFile == null) {
				showAlert(mContext.getString(R.string.file_extract_failed, "app_process"));
				return false;
			}


			// Normal installation
			messages.add(mContext.getString(R.string.file_mounting_writable, "/system"));
			if (mRootUtil.executeWithBusybox("mount -o remount,rw /system", messages) != 0) {
				messages.add(mContext.getString(R.string.file_mount_writable_failed, "/system"));
				messages.add(mContext.getString(R.string.file_trying_to_continue));
			}

			if (new File("/system/bin/app_process.orig").exists()) {
				messages.add(mContext.getString(R.string.file_backup_already_exists, "/system/bin/app_process.orig"));
			} else {
				if (mRootUtil.executeWithBusybox("cp -a /system/bin/app_process /system/bin/app_process.orig", messages) != 0) {
					messages.add("");
					messages.add(mContext.getString(R.string.file_backup_failed, "/system/bin/app_process"));
					return false;
				} else {
					messages.add(mContext.getString(R.string.file_backup_successful, "/system/bin/app_process.orig"));
				}

				mRootUtil.executeWithBusybox("sync", messages);
			}

			messages.add(mContext.getString(R.string.file_copying, "app_process"));
			if (mRootUtil.executeWithBusybox("cp -a " + appProcessFile.getAbsolutePath() + " /system/bin/app_process", messages) != 0) {
				messages.add("");
				messages.add(mContext.getString(R.string.file_copy_failed, "app_process", "/system/bin"));
				return false;
			}
			if (mRootUtil.executeWithBusybox("chmod 755 /system/bin/app_process", messages) != 0) {
				messages.add("");
				messages.add(mContext.getString(R.string.file_set_perms_failed, "/system/bin/app_process"));
				return false;
			}
			if (mRootUtil.executeWithBusybox("chown root:shell /system/bin/app_process", messages) != 0) {
				messages.add("");
				messages.add(mContext.getString(R.string.file_set_owner_failed, "/system/bin/app_process"));
				return false;
			}

			File blocker = new File(XposedApp.BASE_DIR + "conf/disabled");
			if (blocker.exists()) {
				messages.add(mContext.getString(R.string.file_removing, blocker.getAbsolutePath()));
				if (mRootUtil.executeWithBusybox("rm " + blocker.getAbsolutePath(), messages) != 0) {
					messages.add("");
					messages.add(mContext.getString(R.string.file_remove_failed, blocker.getAbsolutePath()));
					return false;
				}
			}

			messages.add(mContext.getString(R.string.file_copying, "XposedBridge.jar"));
			File jarFile = AssetUtil.writeAssetToFile("XposedBridge.jar", new File(JAR_PATH_NEWVERSION), 00644);
			if (jarFile == null) {
				messages.add("");
				messages.add(mContext.getString(R.string.file_extract_failed, "XposedBridge.jar"));
				return false;
			}

			mRootUtil.executeWithBusybox("sync", messages);
			messages.add("");

			return true;

		} finally {
			AssetUtil.removeBusybox();
		}
	}

	private void reboot(String mode) {
		if (!startShell())
			return;

		List<String> messages = new LinkedList<String>();

		String command = "reboot";
		if (mode != null) {
			command += " " + mode;
			if (mode.equals("recovery"))
				// create a flag used by some kernels to boot into recovery
				mRootUtil.executeWithBusybox("touch /cache/recovery/boot", messages);
		}

		if (mRootUtil.executeWithBusybox(command, messages) != 0) {
			messages.add("");
			messages.add(mContext.getString(R.string.reboot_failed));
			showAlert(TextUtils.join("\n", messages).trim());
		}
		AssetUtil.removeBusybox();
	}
	
	private void enableModule(String packageName){
		mModuleUtil.setModuleEnabled(packageName, true);
		mModuleUtil.updateModulesList(false);
	}

	@Override
    public IBinder onBind(Intent intent) {
	    // TODO Auto-generated method stub
	    return null;
    }
}
