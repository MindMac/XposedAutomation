/** Automatically generated file. DO NOT MODIFY */
package de.robv.android.xposed.installer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}